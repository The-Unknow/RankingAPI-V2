# RankingAPI


This project no longer works: https://forums.thecookie.dev/t/free-ranking-with-heroku-is-soon-over-urgent/4300
